//
//  ViewController.swift
//  abc
//
//  Created by Vu Minh Tam on 08/03/2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var text: UITextField!
    
    @IBOutlet weak var type: UITextField!
    
    let C = CalendarData.shared
    let formatter = DateFormatter()
    var typeDay: TypeDayOfWeek = .sunday
    
    override func viewDidLoad() {
        super.viewDidLoad()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
    }

    @IBAction func action(_ sender: Any) {
        let number = Int(type.text!)
        switch number {
        
        case 1:
            typeDay = .sunday
        case 2:
            typeDay = .monday
        case 3:
            typeDay = .tuesday
        case 4:
            typeDay = .wednesday
        case 5:
            typeDay = .thursday
        case 6:
            typeDay = .friday
        case 7:
            typeDay = .saturday
        case .none:
            break
        case .some(_):
            break
        }
        
        let someDateTime = formatter.date(from: text.text!)
        C.generateDaysInMonth(for: someDateTime!)
    }
    
}

