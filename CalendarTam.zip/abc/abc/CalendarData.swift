//
//  CalendarData.swift
//  EnglishListening
//
//  Created by Vu Minh Tam on 04/03/2022.
//  Copyright © 2022 ARISVN. All rights reserved.
//

import Foundation

enum TypeDayOfWeek {
    case sunday // cn 2 3 4 5 6 7
    case monday // 2 3 4 5 6 7 cn
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday // 7 cn 2 3 4 5 6
    
    var kind: Int {
        switch self {
        case .sunday:
            return 0
        case .monday:
            return 1
        case .tuesday:
            return 2
        case .wednesday:
            return 3
        case .thursday:
            return 4
        case .friday:
            return 5
        case .saturday:
            return 6
        }
    }
    
}

struct DayData {
    let date: Date
    let number: String
    let isSelected: Bool
    let isWithinDisplayedMonth: Bool
}

struct MonthMetadata {
    let numberOfDay: Int
    let firstDayOfMonth: Date
    let firstDayWeekday: Int
}

enum CalendarDataError: Error {
  case metadataGeneration
}

class CalendarData {
    static let shared = CalendarData()
    private var calendar = Calendar(identifier: .gregorian)
    public var selectedDate: Date = Date()
    private lazy var dateFormater: DateFormatter = {
       let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "d"
        return dateFormatter
    }()
    
    // cn 2 3 4 5 6 7
    public func generateDaysInMonth(for baseDate: Date) -> [DayData] {
        guard let metadata = try? monthMetadata(for: baseDate) else {
            fatalError("An error occurred when generating the metadata for \(baseDate)")
        }
        let numberOfDaysInMonth = metadata.numberOfDay
        let firstDayOfMonth = metadata.firstDayOfMonth
        let firstDayWeekday = metadata.firstDayWeekday
        
        var days: [DayData] = (1..<(numberOfDaysInMonth + firstDayWeekday))
            .map { day in
                let isWithinDisplayedMonth = day >= firstDayWeekday
                let dayOffSet = isWithinDisplayedMonth ? day - firstDayWeekday : -(firstDayWeekday - day)
                return generateDay(dayOfSet: dayOffSet, baseDate: firstDayOfMonth, isWithinDisplayedMonth: isWithinDisplayedMonth)
            }
        days += generateStartOfNextMonth(firstDayOfDisplayedMonth: firstDayOfMonth)
        
        print("days.count: \(days.count)")
        for i in days {
            print(i.number)
        }
        
        return days
    }
    
    public func monthMetadata(for baseDate: Date) throws -> MonthMetadata {
        guard let numberOfdaysInMonth = calendar.range(of: .day, in: .month, for: baseDate)?.count else {
            throw CalendarDataError.metadataGeneration
        }

        let components = calendar.dateComponents([.year, .month], from: baseDate)
        
        guard let firstDayOfMonth = calendar.date(from: components) else {
            throw CalendarDataError.metadataGeneration
        }
        
        let firstDayWeekday = calendar.component(.weekday, from: firstDayOfMonth)
        
        return MonthMetadata(numberOfDay: numberOfdaysInMonth, firstDayOfMonth: firstDayOfMonth, firstDayWeekday: firstDayWeekday)
    }
    
    private func generateDay(dayOfSet: Int, baseDate: Date, isWithinDisplayedMonth: Bool) -> DayData {
        let date = calendar.date(byAdding: .day, value: dayOfSet, to: baseDate) ?? baseDate
        return DayData(date: date, number: dateFormater.string(from: date), isSelected: calendar.isDate(date, inSameDayAs: selectedDate), isWithinDisplayedMonth: isWithinDisplayedMonth)
    }
    
    private func generateStartOfNextMonth(firstDayOfDisplayedMonth: Date) -> [DayData] {
        guard let lastDayInMonth = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: firstDayOfDisplayedMonth) else {
            return []
        }
        let additionDays = 7 - calendar.component(.weekday, from: lastDayInMonth)
        
        guard additionDays > 0 else {
            return []
        }
        let days: [DayData] = (1...additionDays)
            .map {
                return generateDay(dayOfSet: $0, baseDate: lastDayInMonth, isWithinDisplayedMonth: false)
            }
        return days
    }
}

// case 2 dang con sai chua update code
extension CalendarData {
    // 2 3 4 5 6 7 cn
    public func generateDaysInMonth2(for baseDate: Date, typeDayOfWeek: TypeDayOfWeek = .monday) -> [DayData] {
        guard let metadata = try? monthMetadata(for: baseDate) else {
            fatalError("An error occurred when generating the metadata for \(baseDate)")
        }
        let numberOfDaysInMonth = metadata.numberOfDay
        let firstDayOfMonth = metadata.firstDayOfMonth
        let firstDayWeekday = metadata.firstDayWeekday
        
        var daysOfWeek = 0
        
        if firstDayWeekday < typeDayOfWeek.kind + 1 {
            daysOfWeek = 7 - firstDayWeekday
        } else if firstDayWeekday > typeDayOfWeek.kind + 1 {
            daysOfWeek = firstDayWeekday - 1
        }
        
        var days: [DayData] = (1..<(numberOfDaysInMonth + daysOfWeek))
            .map { day in
                let isWithinDisplayedMonth = day >= daysOfWeek
                let dayOffSet = isWithinDisplayedMonth ? day - daysOfWeek : -(daysOfWeek - day)
                return generateDay(dayOfSet: dayOffSet, baseDate: firstDayOfMonth, isWithinDisplayedMonth: isWithinDisplayedMonth)
            }
        days += generateStartOfNextMonth2(firstDayOfDisplayedMonth: firstDayOfMonth)
        
        print("days.count: \(days.count)")
        for i in days {
            print(i.number)
        }
        
        return days
    }
    
    private func generateStartOfNextMonth2(firstDayOfDisplayedMonth: Date) -> [DayData] {
        guard let lastDayInMonth = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: firstDayOfDisplayedMonth) else {
            return []
        }
        guard let nextLastDayInMonth = calendar.date(byAdding: DateComponents(month: 1, day: -2), to: firstDayOfDisplayedMonth) else {
            return []
        }
        
        let additionDays = 7 - calendar.component(.weekday, from: nextLastDayInMonth)
        
        guard additionDays > 0 else {
            return []
        }
        let days: [DayData] = (1...additionDays)
            .map {
                return generateDay(dayOfSet: $0, baseDate: lastDayInMonth, isWithinDisplayedMonth: false)
            }
        return days
    }
}

// case 3 thu 3 la ngay dau tuan
extension CalendarData {
    // 3 4 5 6 7 cn 2
    public func generateDaysInMonth3(for baseDate: Date, typeDayOfWeek: TypeDayOfWeek) -> [DayData] {
        guard let metadata = try? monthMetadata(for: baseDate) else {
            fatalError("An error occurred when generating the metadata for \(baseDate)")
        }
        let numberOfDaysInMonth = metadata.numberOfDay
        let firstDayOfMonth = metadata.firstDayOfMonth
        let firstDayWeekday = metadata.firstDayWeekday - typeDayOfWeek.kind //   kind = 2
        
        var days: [DayData] = (1..<(numberOfDaysInMonth + firstDayWeekday))
            .map { day in
                let isWithinDisplayedMonth = day >= firstDayWeekday
                let dayOffSet = isWithinDisplayedMonth ? day - firstDayWeekday : -(firstDayWeekday - day)
                return generateDay(dayOfSet: dayOffSet, baseDate: firstDayOfMonth, isWithinDisplayedMonth: isWithinDisplayedMonth)
            }
        days += generateStartOfNextMonth3(firstDayOfDisplayedMonth: firstDayOfMonth)
        
        print("days.count: \(days.count)")
        for i in days {
            print(i.number)
        }
        
        return days
    }
    
    private func generateStartOfNextMonth3(firstDayOfDisplayedMonth: Date) -> [DayData] {
        guard let lastDayInMonth = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: firstDayOfDisplayedMonth) else {
            return []
        }
        guard let nextLastDayInMonth = calendar.date(byAdding: DateComponents(month: 1, day: -3), to: firstDayOfDisplayedMonth) else {
            return []
        }
        
        let additionDays = 7 - calendar.component(.weekday, from: nextLastDayInMonth)
        
        guard additionDays > 0 else {
            return []
        }
        let days: [DayData] = (1...additionDays)
            .map {
                return generateDay(dayOfSet: $0, baseDate: lastDayInMonth, isWithinDisplayedMonth: false)
            }
        return days
    }
}

// case 4 thu 4 la ngay dau tuan
//cn ok
//2 not ok
//3 not ok
//4 ok
//5 not ok
//6 not ok
//7 not ok
extension CalendarData {
    // 4 5 6 7 cn 2 3
    public func generateDaysInMonth4(for baseDate: Date, typeDayOfWeek: TypeDayOfWeek) -> [DayData] {
        guard let metadata = try? monthMetadata(for: baseDate) else {
            fatalError("An error occurred when generating the metadata for \(baseDate)")
        }
        let numberOfDaysInMonth = metadata.numberOfDay
        let firstDayOfMonth = metadata.firstDayOfMonth
        let firstDayWeekday = metadata.firstDayWeekday
        
        var daysOfWeek = 0
        
        if firstDayWeekday < typeDayOfWeek.kind + 1 {
            daysOfWeek = 7 - (typeDayOfWeek.kind + 1 - firstDayWeekday)
        } else if firstDayWeekday > typeDayOfWeek.kind + 1 {
            daysOfWeek = firstDayWeekday - (typeDayOfWeek.kind + 1)
        } else {
            daysOfWeek = 0
        }
        
        var days: [DayData] = (0..<(numberOfDaysInMonth + daysOfWeek))
            .map { day in
                let isWithinDisplayedMonth = day >= daysOfWeek
                var dayOffSet = 0
                if isWithinDisplayedMonth {
                    if firstDayWeekday < typeDayOfWeek.kind + 1 {
                        dayOffSet = day - firstDayWeekday - typeDayOfWeek.kind
                    } else {
                        dayOffSet = day - daysOfWeek
                    }
                } else {
                    dayOffSet = -(daysOfWeek - day)
                }
    
                return generateDay(dayOfSet: dayOffSet, baseDate: firstDayOfMonth, isWithinDisplayedMonth: isWithinDisplayedMonth)
            }
        days += generateStartOfNextMonth4(firstDayOfDisplayedMonth: firstDayOfMonth, typeDayOfWeek: typeDayOfWeek)

        print("days.count: \(days.count)")
        for i in days {
            print(i.number)
        }
        
        return days
    }
    
    private func generateStartOfNextMonth4(firstDayOfDisplayedMonth: Date, typeDayOfWeek: TypeDayOfWeek) -> [DayData] {
        
        
        guard let lastDayInMonth = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: firstDayOfDisplayedMonth) else {
            return []
        }
        let firstDayWeekday = calendar.component(.weekday, from: lastDayInMonth)
        if typeDayOfWeek.kind == firstDayWeekday {
            return [] // neu firstDayWeekday == thu 3 la ok co ko thi phai them ngay
        }
        var additionDays = 0
        if firstDayWeekday > typeDayOfWeek.kind {
            additionDays = 7 - (firstDayWeekday - typeDayOfWeek.kind)
            
        } else if firstDayWeekday < typeDayOfWeek.kind {
            additionDays = typeDayOfWeek.kind  - firstDayWeekday
        }
        
        guard additionDays > 0 else {
            return []
        }
        let days: [DayData] = (1...additionDays)
            .map {
                return generateDay(dayOfSet: $0, baseDate: lastDayInMonth, isWithinDisplayedMonth: false)
            }
        return days
    }
}
